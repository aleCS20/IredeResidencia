package concretDecorator;

import component.Acai;
import decorator.Complement;

public class Straberry extends Complement {

    public Straberry(Acai acai){
        this.acai = acai;
    }

    @Override
    public double price() {
        return acai.price() + 0.50;
    }

    @Override
    public String getDescription() {
        return acai.getDescription() + " with Straberry";
    }
}
