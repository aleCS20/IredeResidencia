package concretDecorator;

import component.Acai;
import decorator.Complement;

public class Banana extends Complement {
    public Banana(Acai acai){
        this.acai = acai;
    }

    @Override
    public double price() {
        return acai.price() + 1.50;
    }

    @Override
    public String getDescription() {
        return acai.getDescription() + " with banana";
    }
}
