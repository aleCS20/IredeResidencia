from flask import Blueprint, request, jsonify
from app.services.teacher_services import TeacherService

teacher_bp = Blueprint('teacher_bp', __name__)

@teacher_bp.route('/teachers/<int:teacher_id>', methods=['GET'])
def get_teacher(teacher_id):
    teacher = TeacherService.get_teacher(teacher_id)
    return jsonify(teacher), 200

@teacher_bp.route('/teachers', methods=['POST'])
def create_teacher():
    data = request.get_json()
    teacher = TeacherService.create_teacher(data)
    return jsonify(teacher), 201

