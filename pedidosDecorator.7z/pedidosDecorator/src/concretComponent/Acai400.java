package concretComponent;

import component.Acai;

public class Acai400 extends Acai {

    @Override
    public double price() {
        return 3.00;
    }

    @Override
    public String getDescription() {
        return description + " in 400";
    }

}
