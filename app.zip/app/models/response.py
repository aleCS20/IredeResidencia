from ..database import db

class Response(db.Model):
    __tablename__ = 'responses'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    response_date = db.Column(db.Date, nullable=False)
    response_text = db.Column(db.String(500))
    response_file = db.Column(db.String(200))
    activity_id = db.Column(db.Integer, db.ForeignKey('activities.id'), nullable=False)
