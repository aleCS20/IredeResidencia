from ..database import db
from ..models.response import Response

class ResponseService:
    @staticmethod
    def get_response(response_id):
        return Response.query.get(response_id)

    @staticmethod
    def create_response(data):
        new_response = Response(**data)
        db.session.add(new_response)
        db.session.commit()
        return new_response
