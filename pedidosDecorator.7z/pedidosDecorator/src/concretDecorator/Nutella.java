package concretDecorator;

import component.Acai;
import decorator.Complement;

public class Nutella extends Complement {

    public Nutella(Acai acai){
        this.acai = acai;
    }

    @Override
    public double price() {
        return acai.price() + 1.00;
    }

    @Override
    public String getDescription() {
        return acai.getDescription() + " with nutella";
    }

}
