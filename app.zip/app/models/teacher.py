from ..database import db
from .user import User

class Teacher(User):
    __tablename__ = 'teachers'
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    qualification = db.Column(db.String(100), nullable=False)
    university = db.Column(db.String(100), nullable=False)
    salary = db.Column(db.Float, nullable=False)

    __mapper_args__ = {
        'polymorphic_identity': 'teacher'
    }
