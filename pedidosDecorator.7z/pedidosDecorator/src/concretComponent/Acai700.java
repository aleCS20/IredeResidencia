package concretComponent;

import component.Acai;

public class Acai700 extends Acai {

    @Override
    public double price() {
        return 6.00;
    }

    @Override
    public String getDescription() {
        return description + " de 700";
    }

}
