from flask import Blueprint, request, jsonify
from app.services.response_services import ResponseService

response_bp = Blueprint('response_bp', __name__)

@response_bp.route('/responses/<int:response_id>', methods=['GET'])
def get_response(response_id):
    response = ResponseService.get_response(response_id)
    return jsonify(response), 200

@response_bp.route('/responses', methods=['POST'])
def create_response():
    data = request.get_json()
    response = ResponseService.create_response(data)
    return jsonify(response), 201
