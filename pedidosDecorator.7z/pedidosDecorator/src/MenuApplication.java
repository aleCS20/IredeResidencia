import component.Acai;
import concretComponent.Acai350;
import concretComponent.Acai400;
import concretComponent.Acai500;
import concretComponent.Acai700;
import concretDecorator.Banana;
import concretDecorator.Mel;
import concretDecorator.Nutella;
import concretDecorator.Straberry;

import java.util.Scanner;

public class MenuApplication {

    public void chooseOneOption(){
        int option;
        System.out.println("Enter the option as above: ");
        Scanner enter = new Scanner(System.in);

        do{
            option = enter.nextInt();
            switch(option){
                case 1:
                    mountAcai350();
                    break;
                case 2:
                    mountAcai400();
                    break;
                case 3:
                    mountAcai500();
                    break;
                case 4:
                    mountAcai700();
                    break;
                case 0:
                    System.out.println("Finalizing Application .... ");
                    break;
                default:
                    System.out.println("Invalid Option .... ");
            }
        } while(option != 0);
    }

    public void mountAcai350(){
        Acai acai1 = new Acai350();
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
        addComplement();
    }

    public void mountAcai400(){
        Acai acai1 = new Acai400();
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
        addComplement();
    }

    public void mountAcai500(){
        Acai acai1 = new Acai500();
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
        addComplement();
    }

    public void mountAcai700(){
        Acai acai1 = new Acai700();
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
        addComplement();
    }

    public void addComplement(){
        Character option;

        System.out.println("Want to add add-on? ");
        Scanner enter = new Scanner(System.in);
        option = enter.next().charAt(0);

        if (option == 's' || option =='S'){
            addComplementAcai();
        } else if (option == 'n' || option == 'N') {

        }
    }

    public void addComplementAcai(){
        int nameComplement, choose = 0;

        System.out.println(" ### ADD COMPLEMENT YOUR AÇAÍ ### ");
        System.out.println("    1 - Banana      ");
        System.out.println("    2 - Mel     ");
        System.out.println("    3 - Nutella     ");
        System.out.println("    4 - Straberry       ");

        System.out.println("Enter the option as above: ");
        Scanner enter = new Scanner(System.in);
        nameComplement = enter.nextInt();
        Option(nameComplement);
    }

    public void Option(int choose){
        switch(choose){
            case 1:
                addComplementBanana();
                break;
            case 2:
                addComplementMel();
                break;
            case 3:
                addComplementNutela();
                break;
            case 4:
                addComplementStraberry();
                break;
            case 0:
                System.out.println("Exit application !!! ");
                break;
        }
    }

    public void addComplementBanana(){
        Acai acai1 = new Acai350();
        acai1 = new Banana(acai1);
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
    }

    public void addComplementMel(){
        Acai acai1 = new Acai400();
        acai1 = new Mel(acai1);
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
    }

    public void addComplementNutela(){
        Acai acai1 = new Acai500();
        acai1 = new Nutella(acai1);
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
    }

    public void addComplementStraberry(){
        Acai acai1 = new Acai700();
        acai1 = new Straberry(acai1);
        System.out.println(acai1.getDescription() + " $ " + acai1.price());
    }

}
