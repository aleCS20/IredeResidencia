package factory;

public interface FactoryAcai {
    void displayDescribeFactory();
    void displayValuesFactory();
}
