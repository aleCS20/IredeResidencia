from ..database import db
from ..models.activity import Activity

class ActivityService:
    @staticmethod
    def get_activity(activity_id):
        return Activity.query.get(activity_id)

    @staticmethod
    def create_activity(data):
        new_activity = Activity(**data)
        db.session.add(new_activity)
        db.session.commit()
        return new_activity
