from flask import Blueprint

from .user_controller import user_bp
from .teacher_controller import teacher_bp
from .student_controller import student_bp
from .classroom_controller import classroom_bp
from .activity_controller import activity_bp
from .response_controller import response_bp

def register_blueprints(app):
    app.register_blueprint(user_bp, url_prefix='/api')
    app.register_blueprint(teacher_bp, url_prefix='/api')
    app.register_blueprint(student_bp, url_prefix='/api')
    app.register_blueprint(classroom_bp, url_prefix='/api')
    app.register_blueprint(activity_bp, url_prefix='/api')
    app.register_blueprint(response_bp, url_prefix='/api')
