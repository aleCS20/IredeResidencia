from flask import Flask
from .config import Config
from .database import db

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    with app.app_context():
        from .models import user, student, teacher, classroom, activity, response
        db.create_all()

    from .controllers import user_controller, student_controller, teacher_controller, classroom_controller, activity_controller, response_controller

    return app
