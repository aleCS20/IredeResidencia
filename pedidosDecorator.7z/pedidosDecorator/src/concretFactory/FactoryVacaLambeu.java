package concretFactory;

import factory.FactoryAcai;

public class FactoryVacaLambeu implements FactoryAcai {

    @Override
    public void displayDescribeFactory(){
        System.out.println(" ###### Factory Vaca Lambeu ###### ");
        System.out.println("Vaca Lambeu offers new sizes of açaí pots ");
    }

    @Override
    public void displayValuesFactory(){
        double valueOfFacotry = 7.50;
        System.out.println("Value of Factory: " + valueOfFacotry +"\n");
    }

}
