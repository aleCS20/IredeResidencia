from ..database import db
from ..models.student import Student

class StudentService:
    @staticmethod
    def get_student(student_id):
        return Student.query.get(student_id)

    @staticmethod
    def create_student(data):
        new_student = Student(**data)
        db.session.add(new_student)
        db.session.commit()
        return new_student
