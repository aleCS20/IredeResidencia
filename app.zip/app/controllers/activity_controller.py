from flask import Blueprint, request, jsonify
from services.activity_services import ActivityService

activity_bp = Blueprint('activity_bp', __name__)

@activity_bp.route('/activities/<int:activity_id>', methods=['GET'])
def get_activity(activity_id):
    activity = ActivityService.get_activity(activity_id)
    return jsonify(activity), 200

@activity_bp.route('/activities', methods=['POST'])
def create_activity():
    data = request.get_json()
    activity = ActivityService.create_activity(data)
    return jsonify(activity), 201
