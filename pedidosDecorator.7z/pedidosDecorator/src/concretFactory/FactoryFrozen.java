package concretFactory;

import factory.FactoryAcai;

public class FactoryFrozen implements FactoryAcai {

    @Override
    public void displayDescribeFactory(){
        System.out.println(" ###### Factory Frozen ###### ");
        System.out.println("Frozen açaí allows you to combine different types of açaí on the market ");
    }

    @Override
    public void displayValuesFactory(){
        double valueOfFacotry = 5.0;
        System.out.println("Value of Factory: " + valueOfFacotry +"\n");
    }

}
