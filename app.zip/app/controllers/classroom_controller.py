from flask import Blueprint, request, jsonify
from ..services.classroom_services import ClassroomService

classroom_bp = Blueprint('classroom_bp', __name__)

@classroom_bp.route('/classrooms/<int:classroom_id>', methods=['GET'])
def get_classroom(classroom_id):
    classroom = ClassroomService.get_classroom(classroom_id)
    return jsonify(classroom), 200

@classroom_bp.route('/classrooms', methods=['POST'])
def create_classroom():
    data = request.get_json()
    classroom = ClassroomService.create_classroom(data)
    return jsonify(classroom), 201
