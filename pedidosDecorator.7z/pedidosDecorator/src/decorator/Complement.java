package decorator;

import component.Acai;

public abstract class Complement extends Acai {
    public Acai acai;
    public abstract String getDescription();
    public abstract double price();
}
