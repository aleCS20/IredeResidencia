
public class MainApplication {
    public static void main(String[] args) {
        MenuApplication execution = new MenuApplication();

        System.out.println(" ### MOUNT YOUR AÇAÍ ### ");
        System.out.println("    1 - Açaí de 350     ");
        System.out.println("    2 - Açaí de 400     ");
        System.out.println("    3 - Açaí de 500     ");
        System.out.println("    4 - Açaí de 700     ");
        System.out.println("    0 - Exit Application ");
        System.out.println(" ######################### ");

        execution.chooseOneOption();
    }
}
