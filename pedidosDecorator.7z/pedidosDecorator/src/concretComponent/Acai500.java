package concretComponent;

import component.Acai;

public class Acai500 extends Acai {

    @Override
    public double price() {
        return 4.00;
    }

    @Override
    public String getDescription() {
        return description + " in 500";
    }

}
