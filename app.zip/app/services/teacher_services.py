from ..database import db
from ..models.teacher import Teacher

class TeacherService:
    @staticmethod
    def get_teacher(teacher_id):
        return Teacher.query.get(teacher_id)

    @staticmethod
    def create_teacher(data):
        new_teacher = Teacher(**data)
        db.session.add(new_teacher)
        db.session.commit()
        return new_teacher
