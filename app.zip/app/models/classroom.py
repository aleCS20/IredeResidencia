from ..database import db

class Classroom(db.Model):
    __tablename__ = 'classrooms'
    id = db.Column(db.Integer, primary_key=True)
    max_students = db.Column(db.Integer, nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teachers.id'), nullable=False)
    students = db.relationship('Student', backref='classroom', lazy=True)
    activities = db.relationship('Activity', backref='classroom', lazy=True)
