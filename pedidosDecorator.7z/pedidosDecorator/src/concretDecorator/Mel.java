package concretDecorator;

import component.Acai;
import decorator.Complement;

public class Mel extends Complement {

    public Mel(Acai acai){
        this.acai = acai;
    }

    @Override
    public double price() {
        return acai.price() + 1.80;
    }

    @Override
    public String getDescription() {
        return acai.getDescription() + " with mel";
    }
}
