from ..database import db
from ..models.classroom import Classroom

class ClassroomService:
    @staticmethod
    def get_classroom(classroom_id):
        return Classroom.query.get(classroom_id)

    @staticmethod
    def create_classroom(data):
        new_classroom = Classroom(**data)
        db.session.add(new_classroom)
        db.session.commit()
        return new_classroom
