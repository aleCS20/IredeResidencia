from flask import Blueprint, request, jsonify
from ..services.student_services import StudentService

student_bp = Blueprint('student_bp', __name__)

@student_bp.route('/students/<int:student_id>', methods=['GET'])
def get_student(student_id):
    student = StudentService.get_student(student_id)
    return jsonify(student), 200

@student_bp.route('/students', methods=['POST'])
def create_student():
    data = request.get_json()
    student = StudentService.create_student(data)
    return jsonify(student), 201
