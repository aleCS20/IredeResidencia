package test;

import component.Acai;
import concretComponent.Acai350;
import concretComponent.Acai400;
import concretComponent.Acai700;
import concretDecorator.Banana;
import concretDecorator.Mel;
import concretDecorator.Straberry;
import concretDecorator.Nutella;
import concretFactory.FactoryFrozen;
import concretFactory.FactoryVacaLambeu;

public class TestDecorator {
    public static void main(String[] args) {

        //Sold the açaí
        System.out.println(" ####### Açaí Sales ####### ");

        //factory Acai Frozen
        FactoryFrozen frozen1 = new FactoryFrozen();
        frozen1.displayDescribeFactory();
        frozen1.displayValuesFactory();

        //factory Acai Frozen
        FactoryVacaLambeu vacaLambeu1 = new FactoryVacaLambeu();
        vacaLambeu1.displayDescribeFactory();
        vacaLambeu1.displayValuesFactory();

        //Açaí simple of the 350
        Acai acai1 = new Acai350();
        System.out.println(acai1.getDescription() + " $ " + acai1.price());

        //Açaí of the 350ml with straberry
        Acai acai2 = new Acai350();
        acai2 = new Straberry(acai2);
        System.out.println(acai2.getDescription() + " $ " + acai2.price());

        //Açaí of the 350ml with nutella
        Acai acai3 = new Acai350();
        acai3 = new Nutella(acai3);
        System.out.println(acai3.getDescription() + " $ " + acai3.price());

        //Açaí of the 350ml with nutella and straberry
        Acai acai4 = new Acai350();
        acai4 = new Nutella(acai4);
        acai4 = new Straberry(acai4);
        System.out.println(acai4.getDescription() + " $ " + acai4.price());

        //Açaí of the 700ml with 2x Straberry and 3xNutella
        Acai acai5 = new Acai700();
        acai5 = new Straberry(acai5);
        //acai5 = new Straberry(acai5);
        acai5 = new Nutella(acai5);
        //acai5 = new Nutella(acai5);
        //acai5 = new Nutella(acai5);
        System.out.println(acai5.getDescription() + " $ " + acai5.price());

        //Açaí of the 400ml with mel and banana
        Acai acai6 = new Acai400();
        acai6 = new Mel(acai6);
        acai6 = new Banana(acai6);
        System.out.println(acai6.getDescription() + " $ " + acai6.price());
    }
}
